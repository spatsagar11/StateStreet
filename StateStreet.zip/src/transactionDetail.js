import React, { Component } from "react";
import "./App.css";

class TransactionDetail extends Component {
  constructor(props) {
    super(props);
    this.state = this.props;
  }
  render() {
    return (
      <div className="App">
        <header className="App-header">
          <h1 className="App-title">
            Transaction {this.props.rowdata.accountName}
          </h1>
        </header>
        <div>Account</div>
      </div>
    );
  }
}

export default TransactionDetail;
